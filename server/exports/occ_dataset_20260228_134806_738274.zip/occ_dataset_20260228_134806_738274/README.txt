Occ Dataset Export
- created_at: 20260228_134806_738274
- target_fps: 30
- sample_every_frames: 15
- total_images: 20
- splits: train:valid:test = 8:1:1
